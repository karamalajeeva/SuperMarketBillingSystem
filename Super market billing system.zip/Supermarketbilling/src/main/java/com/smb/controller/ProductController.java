package com.smb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.smb.model.Product;
import com.smb.service.LoginService;
import com.smb.service.ProductService;

@Controller
@RequestMapping(value="/")
public class ProductController {
	@Autowired
	ProductService productService;
	@Autowired
	LoginService loginService;
	@GetMapping(value="/product")
	public ModelAndView enrollProduct() {
		if(loginService.verifyadmin()==1) {
			return new ModelAndView("AddProduct");
		}
		else {
				return new ModelAndView("redirect:/");
			}
	}
	@GetMapping(value="/productUpdate")
	public ModelAndView UpdateProject() {
		if(loginService.verifyadmin()==1) {
			return new ModelAndView("StockUpdate");
		}
		else {
				return new ModelAndView("redirect:/");
			}
	}
	@GetMapping(value="/product/addproduct")
	public ModelAndView addProduct(@RequestParam Integer productID,
			@RequestParam String productName,@RequestParam Integer quantity,
			@RequestParam Integer amount,@RequestParam String description) {
		Product p=new Product();
		p.setPid(productID);
		p.setPname(productName);
		p.setAmount(amount);
		p.setQuantity(quantity);
		p.setDescription(description);
		String a;
		try {
			a = productService.addProduct(p);
		
			if(a.equals("success")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.successfully added a Product.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else if(a.equals("AlreadyPresent")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Product already present.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Product Unable to add.";
				modelAndView.addObject("Message", message);
				return modelAndView;
				
			}
		} catch (Exception e) {
			return new ModelAndView("ErrorPage");
		}
		
	}
	@GetMapping(value="updatestock")
	public ModelAndView updateStock(@RequestParam Integer productId,
			@RequestParam Integer quantity) {
		try {
		
				String cond=productService.updateStock(productId, quantity);
			
			if(cond.equals("success")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin. Updated "+productId+"in Stock.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			
			else if(cond.equals("NotFound")){
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Please Check Product ID.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Product Unable to update.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
		} catch (Exception e) {
			return new ModelAndView("ErrorPage");
		}
		
	}
}
