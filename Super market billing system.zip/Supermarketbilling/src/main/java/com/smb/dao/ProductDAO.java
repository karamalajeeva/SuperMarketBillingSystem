package com.smb.dao;

import com.smb.model.Product;

public interface ProductDAO {
	public Integer addProduct(Product product) throws Exception;
	public Product getProduct(Integer ProductId) throws Exception;
	public String updateStock(Integer ProductId,Integer quantity)throws Exception;
	
}
