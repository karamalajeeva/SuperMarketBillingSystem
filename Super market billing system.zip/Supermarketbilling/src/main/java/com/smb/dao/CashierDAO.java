package com.smb.dao;

import com.smb.model.Cashier;

public interface CashierDAO {
	public Integer addCashier(Cashier cashier) throws Exception;
	public Cashier getCashier(Integer cid) throws Exception;
	public String updateCashier(Integer CashierID,String CashierName,Integer MobileNumber,String Address,String EmailID,String Password)throws Exception;
	public String deleteCashier(Integer cid)throws Exception;
}
