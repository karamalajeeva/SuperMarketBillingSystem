package com.smb.dao;

import com.smb.model.Admin;

public interface AdminDAO {
	public Admin getAdmin(Integer Aid) throws Exception;
}
